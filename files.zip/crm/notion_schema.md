# CRM: Notion Schema (Suggested)

Use a Notion database (table) for Leads and Appointments if you prefer Notion.

Leads (database) — Properties:
- Name (Title) — text
- Phone (Phone) — phone
- Email (Email) — email
- Address (Text)
- Roof Type (Select) — ["shingle", "metal", "flat", "unsure"]
- Urgency (Select) — ["24_hours", "3_days", "2_weeks", "flexible"]
- Source (Select) — ["website", "facebook", "instagram", "phone", "ads"]
- Status (Select) — ["New", "Contacted", "Booked", "Completed", "Lost"]
- Created (Created time)
- Last Contacted (Date)
- Conversation (Link to Conversations database)
- Appointment (Relation to Appointments database)
- Notes (Text / Long text)

Appointments (database) — Properties:
- Title (Title) — e.g. "Inspection - Jane Doe"
- Lead (Relation) — links to Leads
- Start (Date & time)
- End (Date & time)
- Calendar Event URL (URL)
- Status (Select) — ["Scheduled", "Completed", "Cancelled"]

Conversations (database) — Properties:
- Lead (Relation) — links to Leads
- Channel (Select) — ["chatbot", "sms", "facebook", "call"]
- Messages (Text / Long text) — transcript or snippet
- Timestamp (Created time)

Recommended flows:
- Use Make.com to create/update Notion pages via Notion API when leads are created or updated.
- Store conversation snippets so reps can quickly view history.