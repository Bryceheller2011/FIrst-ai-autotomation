/**
 * Minimal webhook server for Roofing Automation System
 * - Receives website chatbot leads
 * - Receives Facebook Messenger webhook events
 * - Receives Twilio SMS/missed-call webhook events
 *
 * Responsibilities demonstrated:
 * - Validate lead payload
 * - Create lead in Airtable (CRM)
 * - Forward to Make.com webhook for booking automation
 * - Optionally send Twilio SMS (via Make or direct)
 *
 * Note: This is example starter code. In production:
 * - Add authentication/verification (HMAC/webhook secret)
 * - Add retries, logging, metrics and error handling
 * - Use TypeScript and stronger validation
 */

const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
require("dotenv").config();

const app = express();
app.use(bodyParser.json());

// Environment variables (see .env.example)
const {
  PORT = 3000,
  AIRTABLE_API_KEY,
  AIRTABLE_BASE_ID,
  AIRTABLE_LEADS_TABLE = "Leads",
  MAKE_WEBOOK_URL,
  TWILIO_FROM_NUMBER,
  TWILIO_ACCOUNT_SID,
  TWILIO_AUTH_TOKEN,
  GOOGLE_BOOKING_WEBHOOK // optional: Make webhook that creates Google Calendar event
} = process.env;

/**
 * Helper: create lead in Airtable
 */
async function createAirtableLead(lead) {
  if (!AIRTABLE_API_KEY || !AIRTABLE_BASE_ID) {
    console.warn("Airtable is not configured — skipping createAirtableLead");
    return null;
  }
  const url = `https://api.airtable.com/v0/${AIRTABLE_BASE_ID}/${encodeURIComponent(
    AIRTABLE_LEADS_TABLE
  )}`;
  const data = {
    records: [
      {
        fields: {
          Name: lead.name,
          Phone: lead.phone,
          Address: lead.address,
          "Roof Type": lead.roof_type,
          Urgency: lead.urgency,
          Source: lead.source || "web",
          "Initial Message": lead.message || ""
        }
      }
    ]
  };
  const res = await axios.post(url, data, {
    headers: {
      Authorization: `Bearer ${AIRTABLE_API_KEY}`,
      "Content-Type": "application/json"
    }
  });
  return res.data;
}

/**
 * Helper: forward lead to Make.com webhook for workflow orchestration
 */
async function forwardToMake(lead) {
  if (!MAKE_WEBOOK_URL) {
    console.warn("MAKE_WEBOOK_URL not configured — skipping forwardToMake");
    return null;
  }
  const res = await axios.post(MAKE_WEBOOK_URL, { lead });
  return res.data;
}

/**
 * Endpoint: Health check
 */
app.get("/healthz", (req, res) => {
  res.json({ ok: true, ts: Date.now() });
});

/**
 * Endpoint: Website Chatbot / Form webhook
 * Expected payload (example):
 * {
 *   name: "Jane Doe",
 *   phone: "+15551234567",
 *   address: "123 Main St, City, ST",
 *   roof_type: "shingle",
 *   urgency: "2_weeks",
 *   message: "My roof is leaking",
 *   source: "website_chat"
 * }
 */
app.post("/webhook/chat", async (req, res) => {
  try {
    const payload = req.body || {};
    // Basic validation
    const required = ["name", "phone"];
    for (const k of required) {
      if (!payload[k]) {
        return res.status(400).json({ error: `Missing ${k}` });
      }
    }
    // Create lead object with normalized fields
    const lead = {
      name: payload.name,
      phone: payload.phone,
      address: payload.address || "",
      roof_type: payload.roof_type || "unsure",
      urgency: payload.urgency || "unsure",
      message: payload.message || "",
      source: payload.source || "website_chat",
      created_at: new Date().toISOString()
    };

    // 1) Create in Airtable CRM
    const airtableRes = await createAirtableLead(lead).catch((err) => {
      console.error("Airtable create failed", err?.response?.data || err.message);
      return null;
    });

    // 2) Forward to Make.com orchestrator (booking, follow-ups, SMS/email flows)
    const makeRes = await forwardToMake({
      ...lead,
      airtableRecord: airtableRes?.records?.[0] || null
    }).catch((err) => {
      console.error("Make webhook forward failed", err?.response?.data || err.message);
      return null;
    });

    // 3) Immediate response for chatbot
    res.json({
      status: "lead_received",
      airtable: airtableRes ? true : false,
      make: makeRes ? true : false,
      message:
        "Thanks! We received your info. We'll reach out to confirm and book your appointment. If you didn't get a booking link, we'll text one shortly."
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "server_error" });
  }
});

/**
 * Endpoint: Facebook/Instagram webhook (basic verification + event handler)
 * - Facebook requires GET verification endpoint
 * - POST will receive messages (page events)
 */
app.get("/webhook/facebook", (req, res) => {
  const VERIFY_TOKEN = process.env.FB_VERIFY_TOKEN;
  const mode = req.query["hub.mode"];
  const token = req.query["hub.verify_token"];
  const challenge = req.query["hub.challenge"];
  if (mode && token) {
    if (mode === "subscribe" && token === VERIFY_TOKEN) {
      console.log("WEBHOOK_VERIFIED");
      res.status(200).send(challenge);
    } else {
      res.sendStatus(403);
    }
  } else {
    res.sendStatus(400);
  }
});

app.post("/webhook/facebook", async (req, res) => {
  // In production, verify X-Hub-Signature header
  const body = req.body;
  // Example: process messaging events
  try {
    if (body.object === "page") {
      for (const entry of body.entry || []) {
        for (const event of entry.messaging || []) {
          // Extract sender, message text
          const senderId = event.sender?.id;
          const messageText = event.message?.text || "";
          // Build minimal lead and forward to Make.com for follow-up flows
          const lead = {
            name: null,
            phone: null,
            address: null,
            roof_type: "unsure",
            urgency: "unsure",
            message: messageText,
            source: "facebook_messenger",
            external_id: senderId
          };
          await forwardToMake(lead).catch((err) => {
            console.error("forwardToMake failed for FB event", err?.message);
          });
        }
      }
      res.status(200).send("EVENT_RECEIVED");
    } else {
      res.sendStatus(404);
    }
  } catch (err) {
    console.error(err);
    res.sendStatus(500);
  }
});

/**
 * Endpoint: Twilio webhook for SMS/inbound call events (or calls that result in "no answer")
 * Twilio will POST with parameters — provide a JSON-friendly webhook in Make for more complex flows.
 */
app.post("/webhook/twilio/sms", async (req, res) => {
  // Twilio posts application/x-www-form-urlencoded by default
  const body = req.body;
  // Example body contains From, To, Body, SmsStatus
  const from = body.From || body.from;
  const text = body.Body || body.body || "";
  // Create lead and forward
  const lead = {
    name: null,
    phone: from,
    address: null,
    roof_type: "unsure",
    urgency: "unsure",
    message: text,
    source: "twilio_sms"
  };
  await forwardToMake(lead).catch((err) => {
    console.error("forwardToMake failed for twilio", err?.message);
  });
  // Respond to Twilio quickly
  res.set("Content-Type", "text/xml");
  res.send("<Response></Response>");
});

const port = PORT;
app.listen(port, () => {
  console.log(`Webhook server listening on port ${port}`);
});