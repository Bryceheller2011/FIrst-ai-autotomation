# Roofing Automation System

Automates lead capture, qualification, appointment booking, and follow-up for a roofing company across website, social, and phone channels.

This repository contains:
- Webhook server (Node.js/Express) to receive website/chat/facebook/twilio events
- Make.com scenario JSON examples to orchestrate integrations
- CRM schema (Airtable / Notion)
- AI prompts for chatbot and follow-ups
- Step-by-step setup & configuration guide

Folders:
- webhooks/ — webhook server code and samples
- make/ — Make.com (Integromat) scenario JSON examples
- crm/ — Airtable / Notion schema definitions
- prompts/ — chatbot and follow-up prompts/templates
- docs/ — setup guide and integration notes
- samples/ — sample payloads

Read the docs/setup_guide.md for full installation & setup instructions.