# Setup Guide — Roofing Automation System (v1)

This guide walks you through deploying the webhook server, creating Make.com scenarios, configuring Airtable CRM, connecting Twilio, Facebook, and Google Calendar.

1) Provision accounts
- Make.com (Integromat) account
- Airtable account + base
- Twilio account (phone number + SMS)
- Facebook for Developers app + Page + Instagram Basic Display + Messenger
- Google Cloud project with Calendar API enabled (service account for server-to-server or OAuth for Make)

2) Deploy webhook server
- Requirements: Node 18+, npm
- Copy .env.example → .env and fill keys (Airtable API key, base ID, MAKE webhook URL, FB_VERIFY_TOKEN, Twilio creds)
- Install and start:
  - npm install
  - npm start (or use pm2/docker in production)
- Expose server to the internet:
  - Use a stable host (Heroku, Render, Railway) or use ngrok for local testing
- Verify health: GET /healthz

3) Configure Airtable (CRM)
- Create a base named "Roofing CRM"
- Create tables per crm/airtable_schema.json (Leads, Conversations, Appointments)
- Obtain Base ID and API key and put into .env

4) Build Make.com scenarios (high-level)
- Website → Webhook module: gets chat/form payload (use the webhook URL and paste into webhook in server or have your website call /webhook/chat directly)
- Add module: Create record in Airtable (map incoming fields)
- Add router:
  - If booking link available, send SMS/email with booking link
  - Else create Google Calendar draft event (or call calendar booking module)
- Add delays and follow-up checks:
  - 24 hours later, query Airtable — if lead not Booked, send reminder SMS/email
- Add Facebook/Instagram DM scenario:
  - Facebook webhook → Make webhook (same scenario or separate) → follow-up steps
- Add Twilio webhook scenario:
  - Twilio → webhook → create lead & start missed-call SMS flow

Use the make/website_flow.json as a template to create modules. Export scenarios from Make for documentation.

5) Google Calendar booking
Option A (Make-managed):
- Use Make's Google Calendar modules to create events in a team calendar.
- Store event URL back to Airtable Appointment record.

Option B (Direct service):
- Use Google Calendar API via a service account. Make sure the service account has access to a shared resource calendar.

6) Twilio (SMS & call handling)
- Purchase Twilio number and configure webhook URLs:
  - Messaging webhook → {your_server}/webhook/twilio/sms
  - Voice webhook (for missed call detection) → Use Twilio Studio or webhook that POSTs to Make
- Use Twilio API (via Make or directly in server) to send SMS follow-ups with booking link.

7) Facebook & Instagram messaging
- Create Facebook App and Page
- Add Messenger product and subscribe Webhooks:
  - Verify token must match FB_VERIFY_TOKEN in .env
  - Webhook callback: {your_server}/webhook/facebook
- For Page access token, use Make or server to send messages via Graph API if needed
- Instagram DM access requires appropriate app permissions and review for production

8) Rules & Business Logic
- Stop follow-ups when lead.Status == "Booked" or when user replies "STOP" or confirms booking
- On inbound human reply (not STOP), create Conversations record and notify a rep via email/slack
- Maintain a pipeline: New → Contacted → Booked → Completed

9) Weekly reporting
- Use Make to aggregate Airtable data:
  - Total leads (by Created At range)
  - Booked appointments (Appointments table)
  - Lead sources (group by Source)
  - Conversion rate = Booked / Total leads
- Send weekly report as email or Slack message (Make scheduler + Airtable aggregate)

10) Testing checklist
- Send sample payload from samples/sample_payloads.json to /webhook/chat
- Trigger FB message via page to verify webhook
- Simulate Twilio inbound SMS webhook
- Verify records appear in Airtable and follow-up SMS/email is sent (or queued in Make)

11) Security & Privacy
- Store PII in Airtable securely; set team access controls
- Mask logs for phone numbers in public logs
- Implement webhook verification (HMAC, FB signature) in production
- Provide opt-out mechanism for SMS (Twilio handles STOP by default) and honor it in Make/Airtable

12) Next steps (future)
- Paid ads integration (UTM capture + campaign -> lead source)
- AI phone answering (Twilio + Whisper + LLM)
- Proactive outreach for homeowners (consent + compliance)