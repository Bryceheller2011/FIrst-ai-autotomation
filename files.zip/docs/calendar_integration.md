# Google Calendar Integration Notes

Two common approaches to create appointments in Google Calendar.

A) Using Make.com (recommended for v1)
- Use Make Google Calendar modules (Create an Event)
- Authenticate via OAuth or use a service account bound to a shared calendar (Make supports both)
- On success, Map event.htmlLink (or event id) back into Airtable Appointments record

B) Using server-side direct call (Node.js)
- Create a Google Cloud Service Account
- Delegate domain-wide authority or share a calendar with the service account email
- Use googleapis Node client (not provided in example code) to create events
- Map event link back to CRM

Fields to store from Calendar:
- eventId
- htmlLink (public event URL)
- start/end times
- createdBy (system or user)
- attendees (if collecting homeowner email)

Booking considerations:
- Allow buffer times (travel, prep)
- Present available slots (best done via calendar availability API or 3rd-party booking tool)
- Consider using Calendly or Acuity if you prefer a prebuilt booking UI; forward Calendly link in SMS/email.