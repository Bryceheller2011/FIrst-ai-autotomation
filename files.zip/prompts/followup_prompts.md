# Follow-up Templates & Prompts

These templates will be used by automation to send SMS & email.

SMS Flow (Short & actionable)
1) Immediate SMS after form submission:
"Hi {Name}, thanks for contacting {Company}. Book your free roof inspection here: {booking_link} or reply 'CALL' for a call-back. Msg frequency: 3 msgs. Reply STOP to opt-out."

2) 24-hour reminder (if not booked):
"Hi {Name}, still interested in a roof inspection? Secure a slot here: {booking_link} — we have limited openings."

3) 3-day escalation:
"{Name}, we couldn't reach you. If your roof is leaking, reply 'LEAK' for immediate assistance. Otherwise book anytime: {booking_link}"

Email Flow (Longer, more detailed)
1) Welcome email:
Subject: "Thanks for contacting {Company} — Next Steps"
Body:
"Hi {Name},

Thanks for reaching out about your roof. We've received your request and can help with inspections, repairs, and insurance documentation.

Book an inspection here: {booking_link}

If this is an emergency (active leak), call us at {phone}.

— {Company} Team"

2) Follow-up 48 hours:
Subject: "Still need a roof inspection?"
Body:
"Hi {Name},

Wanted to check in — we have availability this week. Book online: {booking_link}

If you'd like us to call, reply to this email or text us."

3) Final 7-day notice:
Subject: "We’re closing your request — last chance to book"
Body:
"Hi {Name},

We haven't heard back. If you'd still like a free inspection, book here: {booking_link}. Otherwise we'll close this request."

Rules for automation:
- Stop sending follow-ups if the lead's status changes to Booked or if they reply with 'STOP' or 'BOOKED' or 'CALL'.
- If inbound reply is human-like (not STOP), escalate to agent inbox (create Conversation record and notify rep).
- Use Twilio for SMS; use SendGrid/Gmail for email.